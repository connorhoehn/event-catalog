#!/usr/bin/env node
// Drift check: fails CI if a NEW file appears in src/components/ OR demo/src/
// that uses `style={{...}}` and isn't on the grandfathered allowlist. Locks in
// the "convert vs keep" heuristic from TAILWIND_MIGRATION.md.
//
// Occurrences inside strings and template literals do NOT count. Several docs
// pages carry JSX code samples in code={`...`} props; a naive grep flags the
// sample text and forces allowlisting files whose real JSX is clean.
//
// The HOISTED form counts too. Until 2026-08-24 this only ever grepped for the
// literal string `style={{`, so moving the identical object to a module-level
// const and writing `style={rowStyle}` — or bundling several into
// `const styles = {...}` and writing `style={styles.row}` — evaded it entirely.
// Eleven demo files were doing exactly that while the guard reported green and
// CLAUDE.md recorded demo eradication as complete. `hasViolation` now resolves
// those references. Note the limits documented on `objectLiteralNames`: an
// object literal built INSIDE a component is not chased, so this is a floor,
// not a proof of absence.
//
// When a file is intentionally added with dynamic inline styles (cursor
// positions, theme-mode colors, prop-driven sizing, etc.) — add its path
// to scripts/check-static-styles.allowlist.txt. Never use the allowlist
// to silence a regression where the styles could have been Tailwind classes.

import { readdirSync, readFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseGuardArgs } from './guard-cli.mjs';

const USAGE = `Usage: ui-check-static-styles [--root <dir>]... [--allowlist <file>]

Fails when a .ts/.tsx file under the roots hand-rolls inline styles
(style={{...}}, or style={x} pointing at a module-level object literal) and is
not on the allowlist (one path per line, # comments).

With no --root, scans this repo's src/components and demo/src against
scripts/check-static-styles.allowlist.txt.`;

const args = parseGuardArgs({ name: 'check-static-styles', scriptUrl: import.meta.url, usage: USAGE });

const scriptDir = dirname(fileURLToPath(import.meta.url));
const DEFAULT_ALLOWLIST = 'scripts/check-static-styles.allowlist.txt';
const allowlistPath = args.allowlistPath ?? (args.custom ? null : resolve(scriptDir, 'check-static-styles.allowlist.txt'));
const allowlistLabel = args.allowlistPath ?? (args.custom ? 'an --allowlist file' : DEFAULT_ALLOWLIST);
const ROOTS = args.custom ? args.roots : ['src/components', 'demo/src'];

const allowed = new Set(
  (allowlistPath ? readFileSync(allowlistPath, 'utf8') : '')
    .split('\n')
    // Strip trailing `# why this is dynamic` notes so each entry can carry
    // its own justification inline. Whole-line comments are dropped too.
    .map((line) => line.replace(/#.*$/, '').trim().replace(/^\.\//, ''))
    .filter(Boolean)
);

// Only real source files. Scanning everything also matches docs (e.g. a JSX
// sample inside pipelines/judge/README.md), which is a false positive the
// allowlist should never have to carry.
//
// Two forms are collected. `style={{` is the literal inline object. `style={`
// alone also catches the HOISTED form — `const rowStyle = {...}` at module
// scope, referenced as `style={rowStyle}` — which is the same hand-rolled
// styling wearing a disguise. The match is deliberately loose; `hasViolation`
// below decides which of those references actually count.
//
// This was `grep -rl` until it became a consumer-runnable bin; a node walk
// keeps it portable and lets it skip node_modules under a consumer root.
const candidates = [];
function walk(dir) {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) {
      if (entry.name !== 'node_modules') walk(path);
      continue;
    }
    if (!entry.isFile() || !/\.tsx?$/.test(entry.name)) continue;
    if (readFileSync(path, 'utf8').includes('style={')) candidates.push(path);
  }
}
for (const root of ROOTS) walk(root);

/** Blank out string/template-literal/comment content, preserving line count. */
/** Does the quote opened at `start` close before the line ends? */
function closesOnSameLine(src, start) {
  const q = src[start];
  for (let j = start + 1; j < src.length; j++) {
    if (src[j] === '\\') { j++; continue; }
    if (src[j] === '\n') return false;
    if (src[j] === q) return true;
  }
  return false;
}

function stripStrings(src) {
  let out = '';
  let i = 0;
  while (i < src.length) {
    const c = src[i];
    if (c === '`' || c === '"' || c === "'") {
      const q = c;
      // A ' or " that never closes on the same line is almost certainly NOT a
      // JS string here — it is an apostrophe in JSX prose. Treating it as a
      // string opener swallows everything up to the next one, which can be
      // dozens of lines away, and that span silently drops out of the check.
      //
      // This is not hypothetical: `demo/src/pages/InstallationPage.tsx` says
      // "your project's .npmrc" on line 27, and the next ' is inside a code
      // sample on line 74. All three `style={codeBlockStyle}` references in
      // between were invisible to this guard, so the file passed while
      // hand-rolling exactly what the guard exists to forbid.
      //
      // Multi-line strings in this codebase use backticks, so backticks keep
      // spanning lines. Getting this wrong in the other direction is safe: a
      // string mistaken for code produces a false POSITIVE, which fails loudly
      // and gets looked at, rather than a hole nobody can see.
      if (q !== '`' && !closesOnSameLine(src, i)) {
        out += c;
        i++;
        continue;
      }
      out += q;
      i++;
      while (i < src.length) {
        if (src[i] === '\\') { i += 2; continue; }
        if (src[i] === q) { out += q; i++; break; }
        out += src[i] === '\n' ? '\n' : ' ';
        i++;
      }
    } else if (c === '/' && src[i + 1] === '/') {
      while (i < src.length && src[i] !== '\n') i++;
    } else if (c === '/' && src[i + 1] === '*') {
      i += 2;
      while (i < src.length && !(src[i] === '*' && src[i + 1] === '/')) {
        out += src[i] === '\n' ? '\n' : '';
        i++;
      }
      i += 2;
    } else {
      out += c;
      i++;
    }
  }
  return out;
}

/**
 * Names bound to a MODULE-LEVEL object literal — `const rowStyle = {`,
 * `const rowStyle: CSSProperties = {`, `const styles = { wrapper: {...} }`.
 * These are what a `style={name}` / `style={styles.name}` reference points at
 * when the styling is static: a literal written once at load time.
 *
 * Two deliberate limits keep this from crying wolf:
 *  - Module level only (the declaration starts at column 0). An object built
 *    inside a component is usually closing over props/state — a dnd-kit
 *    `transform`, a computed position — and is genuinely runtime-derived.
 *  - Object literals only. `useMemo(...)`, a function call, or a prop is not
 *    matched, for the same reason.
 */
function objectLiteralNames(stripped) {
  const names = new Set();
  const re = /^(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*(?::[^=\n]+)?=\s*\{/gm;
  let m;
  while ((m = re.exec(stripped)) !== null) names.add(m[1]);
  return names;
}

/**
 * True when the file hand-rolls inline styling — either the literal
 * `style={{...}}` form, or a `style={x}` whose `x` is an object literal
 * declared in the same file (the hoisted dodge).
 */
function hasViolation(src) {
  const stripped = stripStrings(src);
  if (stripped.includes('style={{')) return true;

  const locals = objectLiteralNames(stripped);
  if (locals.size === 0) return false;

  // Every `style={ ... }` reference, capturing the expression up to the first
  // newline — enough for `style={x}` and `style={a ? b : c}`, and anything
  // longer is an inline object already caught above.
  const re = /\bstyle=\{([^{}\n]*)\}/g;
  let m;
  while ((m = re.exec(stripped)) !== null) {
    const idents = m[1].match(/[A-Za-z_$][\w$]*/g) ?? [];
    if (idents.some((id) => locals.has(id))) return true;
  }
  return false;
}

const current = new Set(
  candidates
    // Test files are not rendered UI. `video/__tests__/classNameSeam.test.tsx`
    // exists precisely to assert that components forward a `style` prop, so it
    // passes a module-level literal into a dozen components on purpose.
    .filter((f) => !f.includes('__tests__') && !/\.test\.tsx?$/.test(f))
    // Keep only files whose REAL code (not code samples in strings) uses it.
    .filter((f) => hasViolation(readFileSync(f, 'utf8')))
);

const additions = [...current].filter((f) => !allowed.has(f)).sort();
const removals = [...allowed].filter((f) => !current.has(f)).sort();

if (additions.length > 0) {
  process.stderr.write(
    '\nX check-static-styles: new file(s) with hand-rolled inline styles detected\n' +
      '(either `style={{...}}` or a `style={x}` pointing at a module-level object literal):\n\n'
  );
  for (const f of additions) process.stderr.write('  ' + f + '\n');
  process.stderr.write(
    '\nIf the style values are dynamic (computed from props / state / runtime data) and cannot be expressed as Tailwind classes,\n' +
      'add the path(s) to ' + allowlistLabel + '.\n\n' +
      'If the values are static literals, convert them to Tailwind classes via cn() instead.\n' +
      'See TAILWIND_MIGRATION.md ("convert vs keep" heuristic).\n'
  );
  process.exit(1);
}

if (removals.length > 0) {
  process.stdout.write(
    '\nok check-static-styles: pass.\n\nNote: ' +
      removals.length +
      ' allowlisted file(s) no longer hand-roll inline styles and may be removed from the allowlist:\n'
  );
  for (const f of removals) process.stdout.write('  - ' + f + '\n');
} else {
  process.stdout.write('ok check-static-styles: pass (' + current.size + ' allowlisted file(s)).\n');
}
